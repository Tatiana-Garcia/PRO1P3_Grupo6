#pragma once
#include <fstream>
#include <iostream>
#include <string>
#include <regex>
using namespace std;
class Trapecio
{
public:
	static void Dibujar(int a, int b, int c, int h, int B);
};

