#pragma once
#include <fstream>
#include <iostream>
#include <string>
#include <regex>
using namespace std;
class Rectangulo
{
public:
	static void Dibujar(int a, int b);
};

