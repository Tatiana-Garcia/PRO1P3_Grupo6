#pragma once
#include <fstream>
#include <iostream>
#include <string>
#include <regex>
using namespace std;

class Rombo{
public: 
	static void Dibujar(int a, int d, int D);
};

