#pragma once
#include <fstream>
#include <iostream>
#include <string>
#include <regex>
using namespace std;
class Cometa
{
public:
	static void Dibujar(int a, int b, int d, int D);
};

