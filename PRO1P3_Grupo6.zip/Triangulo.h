#pragma once
#include <fstream>
#include <iostream>
#include <string> 
#include <regex>
using namespace std;
class Triangulo
{
public: 
	static void Dibujar(int a, int b, int c, int h);
};

