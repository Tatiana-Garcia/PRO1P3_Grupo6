#pragma once
#include <fstream>
#include <iostream>
#include <string>
#include <regex>
using namespace std;
class Cuadrado
{
public: 
	static void Dibujar(int a);
};

