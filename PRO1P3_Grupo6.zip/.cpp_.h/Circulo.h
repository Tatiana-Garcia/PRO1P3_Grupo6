#pragma once
#include <fstream>
#include <iostream>
#include <iomanip>
#include <string>
#include <regex>
#include <cmath>
#include <sstream>
# define PI 3.14159265358979323846
using namespace std;
class Circulo
{
public:
	static void Dibujar(int r);

};